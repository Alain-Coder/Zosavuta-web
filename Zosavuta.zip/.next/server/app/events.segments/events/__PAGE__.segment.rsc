1:"$Sreact.fragment"
3:I[897367,["/_next/static/chunks/22b49oucsye0d.js","/_next/static/chunks/2eu9x6jqtcrjb.js","/_next/static/chunks/1s_kogv9ptuf7.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/1f8b1vr9ruonp.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":["$L2",null,["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"PguD2ycitHEec63gmWmSO"}
5:null
2:E{"digest":"NEXT_REDIRECT;replace;/;307;"}
