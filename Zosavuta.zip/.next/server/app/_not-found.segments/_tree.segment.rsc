:HL["/_next/static/chunks/2so_4r2w0y9j2.css","style"]
:HL["/_next/static/chunks/24i1nr4h_dinz.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"PguD2ycitHEec63gmWmSO"}
