1:"$Sreact.fragment"
2:I[339756,["/_next/static/chunks/22b49oucsye0d.js","/_next/static/chunks/2eu9x6jqtcrjb.js","/_next/static/chunks/1s_kogv9ptuf7.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/1f8b1vr9ruonp.js"],"default"]
3:I[837457,["/_next/static/chunks/22b49oucsye0d.js","/_next/static/chunks/2eu9x6jqtcrjb.js","/_next/static/chunks/1s_kogv9ptuf7.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/1f8b1vr9ruonp.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"PguD2ycitHEec63gmWmSO"}
