1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/092__600xxnxs.js","/_next/static/chunks/0jk7emkjztqo7.js","/_next/static/chunks/068mhazwr0o2h.js","/_next/static/chunks/2tsab04npe_fw.js","/_next/static/chunks/44p37290qsddb.js","/_next/static/chunks/1iz8m11em8zi_.js","/_next/static/chunks/1-zekpncv9_9m.js","/_next/static/chunks/0tssc4fp_lb6d.js"],"default"]
3:I[37457,["/_next/static/chunks/092__600xxnxs.js","/_next/static/chunks/0jk7emkjztqo7.js","/_next/static/chunks/068mhazwr0o2h.js","/_next/static/chunks/2tsab04npe_fw.js","/_next/static/chunks/44p37290qsddb.js","/_next/static/chunks/1iz8m11em8zi_.js","/_next/static/chunks/1-zekpncv9_9m.js","/_next/static/chunks/0tssc4fp_lb6d.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"pErstiiVugf2uYA2j_PGy"}
