1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/0jk7emkjztqo7.js","/_next/static/chunks/44p37290qsddb.js","/_next/static/chunks/0tssc4fp_lb6d.js","/_next/static/chunks/2e2aqeh2dmi7o.js","/_next/static/chunks/3gx719e7nz0lg.js"],"default"]
3:I[37457,["/_next/static/chunks/0jk7emkjztqo7.js","/_next/static/chunks/44p37290qsddb.js","/_next/static/chunks/0tssc4fp_lb6d.js","/_next/static/chunks/2e2aqeh2dmi7o.js","/_next/static/chunks/3gx719e7nz0lg.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"GEIGnHMwBmAt2gEPfuZ0z"}
