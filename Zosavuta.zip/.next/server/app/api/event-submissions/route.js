var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/event-submissions/route.js")
R.c("server/chunks/[root-of-the-server]__19n-rou._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__1_30tpt._.js")
R.c("server/chunks/_next-internal_server_app_api_event-submissions_route_actions_04zq7zn.js")
R.m(278344)
module.exports=R.m(278344).exports
