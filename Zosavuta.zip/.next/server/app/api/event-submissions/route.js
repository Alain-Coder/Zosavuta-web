var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/event-submissions/route.js")
R.c("server/chunks/[root-of-the-server]__1pms7ad._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_event-submissions_route_actions_04zq7zn.js")
R.m(78344)
module.exports=R.m(78344).exports
