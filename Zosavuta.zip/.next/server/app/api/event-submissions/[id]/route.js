var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/event-submissions/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1wtsc3k._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_event-submissions_[id]_route_actions_18_rngl.js")
R.m(93419)
module.exports=R.m(93419).exports
