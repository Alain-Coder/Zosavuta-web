var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/event-submissions/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__2054y_q._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__1_30tpt._.js")
R.c("server/chunks/_next-internal_server_app_api_event-submissions_[id]_route_actions_18_rngl.js")
R.m(293419)
module.exports=R.m(293419).exports
