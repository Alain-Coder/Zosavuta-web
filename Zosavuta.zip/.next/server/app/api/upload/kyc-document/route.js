var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/upload/kyc-document/route.js")
R.c("server/chunks/[root-of-the-server]__09l1url._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_upload_kyc-document_route_actions_1my4j-m.js")
R.m(409857)
module.exports=R.m(409857).exports
