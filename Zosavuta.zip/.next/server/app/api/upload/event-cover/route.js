var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/upload/event-cover/route.js")
R.c("server/chunks/[root-of-the-server]__1aqewzk._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_upload_event-cover_route_actions_0qddkgp.js")
R.m(784439)
module.exports=R.m(784439).exports
