var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/financial-verifications/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_1bbl9x3.js")
R.c("server/chunks/[root-of-the-server]__056r4ik._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/1oeh_server_app_api_admin_financial-verifications_route_actions_1c4fskc.js")
R.m(713514)
module.exports=R.m(713514).exports
