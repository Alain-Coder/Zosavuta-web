var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/financial-verifications/route.js")
R.c("server/chunks/[root-of-the-server]__1gya56y._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/1oeh_server_app_api_admin_financial-verifications_route_actions_1c4fskc.js")
R.m(13514)
module.exports=R.m(13514).exports
