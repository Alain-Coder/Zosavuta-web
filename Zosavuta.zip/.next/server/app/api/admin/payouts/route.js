var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/payouts/route.js")
R.c("server/chunks/[root-of-the-server]__1tjzjgk._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_payouts_route_actions_00twh4m.js")
R.m(56578)
module.exports=R.m(56578).exports
