var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/payouts/route.js")
R.c("server/chunks/[root-of-the-server]__203nci1._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_payouts_route_actions_00twh4m.js")
R.m(856578)
module.exports=R.m(856578).exports
