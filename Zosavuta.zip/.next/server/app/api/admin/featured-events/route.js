var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/featured-events/route.js")
R.c("server/chunks/[root-of-the-server]__15zcfxz._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_featured-events_route_actions_1d8tnrw.js")
R.m(372313)
module.exports=R.m(372313).exports
