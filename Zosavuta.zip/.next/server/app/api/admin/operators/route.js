var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/operators/route.js")
R.c("server/chunks/[root-of-the-server]__0hqv2_1._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_operators_route_actions_0a-1-02.js")
R.m(23719)
module.exports=R.m(23719).exports
