var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/operators/route.js")
R.c("server/chunks/[root-of-the-server]__1mj4orh._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_operators_route_actions_0a-1-02.js")
R.m(23719)
module.exports=R.m(23719).exports
