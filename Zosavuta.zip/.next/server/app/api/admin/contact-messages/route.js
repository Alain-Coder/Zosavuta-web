var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/contact-messages/route.js")
R.c("server/chunks/[root-of-the-server]__0sg5w_x._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_contact-messages_route_actions_01y5txk.js")
R.m(11983)
module.exports=R.m(11983).exports
