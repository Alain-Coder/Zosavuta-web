var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/submissions/[id]/approve/route.js")
R.c("server/chunks/[root-of-the-server]__0egzigt._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/1oeh_server_app_api_admin_submissions_[id]_approve_route_actions_20r14rw.js")
R.m(15556)
module.exports=R.m(15556).exports
