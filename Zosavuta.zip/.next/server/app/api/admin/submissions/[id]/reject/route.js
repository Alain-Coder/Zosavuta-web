var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/submissions/[id]/reject/route.js")
R.c("server/chunks/[root-of-the-server]__06xs3mo._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/1oeh_server_app_api_admin_submissions_[id]_reject_route_actions_1_bcbov.js")
R.m(87716)
module.exports=R.m(87716).exports
