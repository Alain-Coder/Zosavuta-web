var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/organizer-verifications/[id]/history/route.js")
R.c("server/chunks/[root-of-the-server]__0oovboj._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/1oeh_server_app_api_admin_organizer-verifications_[id]_history_route_actions_1fie-bq.js")
R.m(76893)
module.exports=R.m(76893).exports
