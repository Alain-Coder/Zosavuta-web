var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/organizer-verifications/route.js")
R.c("server/chunks/[root-of-the-server]__04wzczl._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__1_30tpt._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/1oeh_server_app_api_admin_organizer-verifications_route_actions_1cwejnn.js")
R.m(994982)
module.exports=R.m(994982).exports
