var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/organizer-verifications/route.js")
R.c("server/chunks/[root-of-the-server]__0vl7ck9._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/1oeh_server_app_api_admin_organizer-verifications_route_actions_1cwejnn.js")
R.m(94982)
module.exports=R.m(94982).exports
