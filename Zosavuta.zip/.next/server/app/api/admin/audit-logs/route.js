var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/audit-logs/route.js")
R.c("server/chunks/[root-of-the-server]__0sq65pb._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_audit-logs_route_actions_02hwzqu.js")
R.m(98836)
module.exports=R.m(98836).exports
