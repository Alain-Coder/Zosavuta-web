var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/operator/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1xw-gwh._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_operator_[id]_route_actions_0r8tyti.js")
R.m(344115)
module.exports=R.m(344115).exports
