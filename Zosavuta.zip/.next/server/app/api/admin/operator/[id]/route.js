var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/operator/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1_vy9oc._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_operator_[id]_route_actions_0r8tyti.js")
R.m(44115)
module.exports=R.m(44115).exports
