var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/ticket-approvals/route.js")
R.c("server/chunks/[root-of-the-server]__1lht2ld._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_ticket-approvals_route_actions_0u4tzky.js")
R.m(19112)
module.exports=R.m(19112).exports
