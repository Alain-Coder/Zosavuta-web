var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/analytics/route.js")
R.c("server/chunks/[root-of-the-server]__1jvqgjc._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_1b3k7-l.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_analytics_route_actions_05f7pfj.js")
R.m(341461)
module.exports=R.m(341461).exports
