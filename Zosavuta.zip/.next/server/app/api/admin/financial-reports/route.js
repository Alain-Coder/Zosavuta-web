var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/financial-reports/route.js")
R.c("server/chunks/[root-of-the-server]__0fqrc1y._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_financial-reports_route_actions_0mladuw.js")
R.m(18738)
module.exports=R.m(18738).exports
