var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/financial-reports/route.js")
R.c("server/chunks/[root-of-the-server]__0ta473i._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_financial-reports_route_actions_0mladuw.js")
R.m(118738)
module.exports=R.m(118738).exports
