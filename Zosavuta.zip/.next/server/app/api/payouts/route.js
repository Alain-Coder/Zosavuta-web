var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/payouts/route.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0h3eric.js")
R.c("server/chunks/[root-of-the-server]__0y8ufta._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/_next-internal_server_app_api_payouts_route_actions_0apkmtf.js")
R.m(976790)
module.exports=R.m(976790).exports
