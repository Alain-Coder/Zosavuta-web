var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/payouts/route.js")
R.c("server/chunks/[root-of-the-server]__0qjeb8z._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_payouts_route_actions_0apkmtf.js")
R.m(76790)
module.exports=R.m(76790).exports
