var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payouts/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__0_op6up._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_payouts_webhook_route_actions_1igdz7b.js")
R.m(3522)
module.exports=R.m(3522).exports
