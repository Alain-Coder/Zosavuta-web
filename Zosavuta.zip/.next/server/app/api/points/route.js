var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/points/route.js")
R.c("server/chunks/[root-of-the-server]__0t2fyv_._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_points_route_actions_00bha1-.js")
R.m(137218)
module.exports=R.m(137218).exports
