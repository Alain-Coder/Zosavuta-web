var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/resale/initialize-payment/route.js")
R.c("server/chunks/[root-of-the-server]__1ccml86._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_resale_initialize-payment_route_actions_0ay5sfy.js")
R.m(43986)
module.exports=R.m(43986).exports
