var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/resale/route.js")
R.c("server/chunks/[root-of-the-server]__0ymhf-x._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_resale_route_actions_0azjz8j.js")
R.m(336741)
module.exports=R.m(336741).exports
