var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/resale/route.js")
R.c("server/chunks/[root-of-the-server]__1jv8jmz._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_resale_route_actions_0azjz8j.js")
R.m(36741)
module.exports=R.m(36741).exports
