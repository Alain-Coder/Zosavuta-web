var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/resale/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__213rwwr._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_resale_[id]_route_actions_1iqmux-.js")
R.m(376887)
module.exports=R.m(376887).exports
