var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/resale/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__024c5sx._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_resale_[id]_route_actions_1iqmux-.js")
R.m(76887)
module.exports=R.m(76887).exports
