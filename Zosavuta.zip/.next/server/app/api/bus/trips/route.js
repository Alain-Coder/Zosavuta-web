var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bus/trips/route.js")
R.c("server/chunks/[root-of-the-server]__1ogdc3u._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_bus_trips_route_actions_02ctigh.js")
R.m(3821)
module.exports=R.m(3821).exports
