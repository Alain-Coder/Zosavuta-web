var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bus/trips/route.js")
R.c("server/chunks/[root-of-the-server]__1z5zg20._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_bus_trips_route_actions_02ctigh.js")
R.m(103821)
module.exports=R.m(103821).exports
