var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bus/trips/route.js")
R.c("server/chunks/[root-of-the-server]__0yiiunk._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_bus_trips_route_actions_02ctigh.js")
R.m(3821)
module.exports=R.m(3821).exports
