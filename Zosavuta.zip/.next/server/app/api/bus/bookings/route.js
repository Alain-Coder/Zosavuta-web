var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bus/bookings/route.js")
R.c("server/chunks/[root-of-the-server]__010k2io._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_bus_bookings_route_actions_0z25kn1.js")
R.m(16461)
module.exports=R.m(16461).exports
