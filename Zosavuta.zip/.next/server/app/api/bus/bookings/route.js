var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bus/bookings/route.js")
R.c("server/chunks/[root-of-the-server]__0lxiqk-._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_bus_bookings_route_actions_0z25kn1.js")
R.m(16461)
module.exports=R.m(16461).exports
