var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bus/operators/route.js")
R.c("server/chunks/[root-of-the-server]__0jjf-4g._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_bus_operators_route_actions_0sl60t4.js")
R.m(741114)
module.exports=R.m(741114).exports
