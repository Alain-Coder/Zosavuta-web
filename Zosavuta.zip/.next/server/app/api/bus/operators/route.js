var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bus/operators/route.js")
R.c("server/chunks/[root-of-the-server]__1jpyn03._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_bus_operators_route_actions_0sl60t4.js")
R.m(41114)
module.exports=R.m(41114).exports
