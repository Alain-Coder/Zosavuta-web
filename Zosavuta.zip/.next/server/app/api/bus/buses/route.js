var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bus/buses/route.js")
R.c("server/chunks/[root-of-the-server]__1lb7x5j._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_bus_buses_route_actions_1ynkp6n.js")
R.m(14511)
module.exports=R.m(14511).exports
