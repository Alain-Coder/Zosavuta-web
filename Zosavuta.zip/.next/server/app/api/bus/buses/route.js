var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bus/buses/route.js")
R.c("server/chunks/[root-of-the-server]__177zfoj._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_bus_buses_route_actions_1ynkp6n.js")
R.m(14511)
module.exports=R.m(14511).exports
