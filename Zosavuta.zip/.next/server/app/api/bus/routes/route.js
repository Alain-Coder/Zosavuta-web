var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bus/routes/route.js")
R.c("server/chunks/[root-of-the-server]__0u8roez._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_bus_routes_route_actions_1m5lejj.js")
R.m(86393)
module.exports=R.m(86393).exports
