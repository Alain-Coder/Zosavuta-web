var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bus/routes/route.js")
R.c("server/chunks/[root-of-the-server]__04f_vs9._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_bus_routes_route_actions_1m5lejj.js")
R.m(86393)
module.exports=R.m(86393).exports
