var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/organizer/physical-tickets/sell/route.js")
R.c("server/chunks/[root-of-the-server]__1mwz0_5._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/1oeh_server_app_api_organizer_physical-tickets_sell_route_actions_0qu4kob.js")
R.m(37414)
module.exports=R.m(37414).exports
