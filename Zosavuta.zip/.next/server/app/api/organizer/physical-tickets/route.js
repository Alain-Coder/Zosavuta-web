var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/organizer/physical-tickets/route.js")
R.c("server/chunks/[root-of-the-server]__1_pixn0._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_organizer_physical-tickets_route_actions_0vp7nok.js")
R.m(402653)
module.exports=R.m(402653).exports
