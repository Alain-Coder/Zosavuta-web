var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/organizer/physical-tickets/route.js")
R.c("server/chunks/[root-of-the-server]__0-kpwn1._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_organizer_physical-tickets_route_actions_0vp7nok.js")
R.m(2653)
module.exports=R.m(2653).exports
