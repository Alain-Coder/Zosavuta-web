var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/organizer/physical-tickets/return/route.js")
R.c("server/chunks/[root-of-the-server]__1-2284h._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/1oeh_server_app_api_organizer_physical-tickets_return_route_actions_1fbcbs6.js")
R.m(4390)
module.exports=R.m(4390).exports
