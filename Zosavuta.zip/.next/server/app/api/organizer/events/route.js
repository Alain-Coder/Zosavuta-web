var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/organizer/events/route.js")
R.c("server/chunks/[root-of-the-server]__06f74mc._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_organizer_events_route_actions_0tbacnc.js")
R.m(797952)
module.exports=R.m(797952).exports
