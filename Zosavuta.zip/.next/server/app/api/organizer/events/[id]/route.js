var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/organizer/events/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__036v0lo._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_organizer_events_[id]_route_actions_0zmt58p.js")
R.m(84965)
module.exports=R.m(84965).exports
