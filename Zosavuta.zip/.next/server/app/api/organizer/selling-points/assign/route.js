var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/organizer/selling-points/assign/route.js")
R.c("server/chunks/[root-of-the-server]__1tswtsh._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/1oeh_server_app_api_organizer_selling-points_assign_route_actions_0gdq6t3.js")
R.m(419729)
module.exports=R.m(419729).exports
