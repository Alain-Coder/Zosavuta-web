var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/organizer/selling-points/route.js")
R.c("server/chunks/[root-of-the-server]__1qpdwww._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_organizer_selling-points_route_actions_12dtato.js")
R.m(568329)
module.exports=R.m(568329).exports
