var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/organizer/tickets/verify/route.js")
R.c("server/chunks/[root-of-the-server]__1ew0bpj._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_organizer_tickets_verify_route_actions_1a7njp5.js")
R.m(802577)
module.exports=R.m(802577).exports
