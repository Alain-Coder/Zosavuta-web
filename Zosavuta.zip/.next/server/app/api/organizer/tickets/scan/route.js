var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/organizer/tickets/scan/route.js")
R.c("server/chunks/[root-of-the-server]__1_28aqn._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_organizer_tickets_scan_route_actions_0qct52p.js")
R.m(841552)
module.exports=R.m(841552).exports
