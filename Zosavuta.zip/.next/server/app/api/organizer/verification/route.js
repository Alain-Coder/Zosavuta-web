var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/organizer/verification/route.js")
R.c("server/chunks/[root-of-the-server]__1kqynj7._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0ecz0d9.js")
R.c("server/chunks/[root-of-the-server]__1_30tpt._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_organizer_verification_route_actions_0y_veki.js")
R.m(40825)
module.exports=R.m(40825).exports
