var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/email-verification/send/route.js")
R.c("server/chunks/[root-of-the-server]__1k-8h91._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/[root-of-the-server]__1_30tpt._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/_next-internal_server_app_api_auth_email-verification_send_route_actions_1q959v0.js")
R.m(74384)
module.exports=R.m(74384).exports
