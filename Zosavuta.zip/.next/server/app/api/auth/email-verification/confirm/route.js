var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/email-verification/confirm/route.js")
R.c("server/chunks/[root-of-the-server]__08wxev0._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__1_30tpt._.js")
R.c("server/chunks/1oeh_server_app_api_auth_email-verification_confirm_route_actions_0ukfuhz.js")
R.m(685840)
module.exports=R.m(685840).exports
