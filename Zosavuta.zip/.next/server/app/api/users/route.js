var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/users/route.js")
R.c("server/chunks/[root-of-the-server]__1bpmyqe._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_users_route_actions_0mvbx1f.js")
R.m(72797)
module.exports=R.m(72797).exports
