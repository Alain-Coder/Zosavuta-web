var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/users/route.js")
R.c("server/chunks/[root-of-the-server]__1a7kjmt._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_users_route_actions_0mvbx1f.js")
R.m(272797)
module.exports=R.m(272797).exports
