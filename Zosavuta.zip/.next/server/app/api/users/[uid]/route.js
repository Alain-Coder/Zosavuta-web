var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/users/[uid]/route.js")
R.c("server/chunks/[root-of-the-server]__05sxb96._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_users_[uid]_route_actions_1835hvc.js")
R.m(18526)
module.exports=R.m(18526).exports
