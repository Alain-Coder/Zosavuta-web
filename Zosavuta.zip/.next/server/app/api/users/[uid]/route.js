var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/users/[uid]/route.js")
R.c("server/chunks/[root-of-the-server]__09i35i-._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_users_[uid]_route_actions_1835hvc.js")
R.m(18526)
module.exports=R.m(18526).exports
