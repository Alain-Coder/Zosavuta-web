var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/initialize/route.js")
R.c("server/chunks/[root-of-the-server]__0rdolox._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_payments_initialize_route_actions_0u040lg.js")
R.m(627473)
module.exports=R.m(627473).exports
