var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/initialize/route.js")
R.c("server/chunks/[root-of-the-server]__151zh_s._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_payments_initialize_route_actions_0u040lg.js")
R.m(27473)
module.exports=R.m(27473).exports
