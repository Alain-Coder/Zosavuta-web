var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/webhook/route.js")
R.c("server/chunks/[root-of-the-server]__1hqi0vo._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_payments_webhook_route_actions_1mbehel.js")
R.m(98924)
module.exports=R.m(98924).exports
