var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/banks/route.js")
R.c("server/chunks/[root-of-the-server]__0udm0gr._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_banks_route_actions_1pd7zu9.js")
R.m(452394)
module.exports=R.m(452394).exports
