var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/orders/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__20266a-._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_orders_[id]_route_actions_170f1_8.js")
R.m(32628)
module.exports=R.m(32628).exports
