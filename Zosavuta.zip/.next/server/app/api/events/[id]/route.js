var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/events/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__047bp6c._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_events_[id]_route_actions_1n622uq.js")
R.m(64088)
module.exports=R.m(64088).exports
