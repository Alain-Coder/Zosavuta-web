var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/events/route.js")
R.c("server/chunks/[root-of-the-server]__0b4u1bm._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_events_route_actions_1ozh0xo.js")
R.m(78449)
module.exports=R.m(78449).exports
