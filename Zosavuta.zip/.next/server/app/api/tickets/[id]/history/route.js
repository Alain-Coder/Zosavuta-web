var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/tickets/[id]/history/route.js")
R.c("server/chunks/[root-of-the-server]__0pu1vz0._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_tickets_[id]_history_route_actions_1oae-5j.js")
R.m(84198)
module.exports=R.m(84198).exports
