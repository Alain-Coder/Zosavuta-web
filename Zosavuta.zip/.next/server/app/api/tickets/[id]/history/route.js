var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/tickets/[id]/history/route.js")
R.c("server/chunks/[root-of-the-server]__0fkr5fu._.js")
R.c("server/chunks/[root-of-the-server]__0ya4-n_._.js")
R.c("server/chunks/_next-internal_server_app_api_tickets_[id]_history_route_actions_1oae-5j.js")
R.m(84198)
module.exports=R.m(84198).exports
