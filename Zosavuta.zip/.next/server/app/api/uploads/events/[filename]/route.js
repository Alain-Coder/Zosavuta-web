var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/uploads/events/[filename]/route.js")
R.c("server/chunks/[root-of-the-server]__1ymm8qb._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_uploads_events_[filename]_route_actions_0vb17xf.js")
R.m(203185)
module.exports=R.m(203185).exports
