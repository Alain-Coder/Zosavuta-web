var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/uploads/kyc/[filename]/route.js")
R.c("server/chunks/[root-of-the-server]__0u-38rd._.js")
R.c("server/chunks/_03-pcnk._.js")
R.c("server/chunks/[root-of-the-server]__0xuaoik._.js")
R.c("server/chunks/_next-internal_server_app_api_uploads_kyc_[filename]_route_actions_1tosd5_.js")
R.m(117554)
module.exports=R.m(117554).exports
