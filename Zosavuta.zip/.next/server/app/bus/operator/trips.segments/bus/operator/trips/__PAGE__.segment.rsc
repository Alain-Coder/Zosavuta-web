1:"$Sreact.fragment"
2:I[97367,["/_next/static/chunks/0jk7emkjztqo7.js","/_next/static/chunks/44p37290qsddb.js","/_next/static/chunks/0tssc4fp_lb6d.js","/_next/static/chunks/2e2aqeh2dmi7o.js","/_next/static/chunks/3gx719e7nz0lg.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","div",null,{"className":"space-y-6","children":[["$","h1",null,{"className":"text-3xl font-bold","children":"Trip Scheduling"}],["$","p",null,{"children":"No trips scheduled yet."}]]}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"GEIGnHMwBmAt2gEPfuZ0z"}
4:null
