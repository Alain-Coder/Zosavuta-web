1:"$Sreact.fragment"
2:I[897367,["/_next/static/chunks/22b49oucsye0d.js","/_next/static/chunks/2eu9x6jqtcrjb.js","/_next/static/chunks/1s_kogv9ptuf7.js","/_next/static/chunks/1ntn7efqc-iiw.js","/_next/static/chunks/1f8b1vr9ruonp.js"],"OutletBoundary"]
3:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","div",null,{"className":"space-y-6","children":[["$","h1",null,{"className":"text-3xl font-bold","children":"Route Management"}],["$","p",null,{"children":"Here you can add, edit, and remove bus routes."}]]}],null,["$","$L2",null,{"children":["$","$3",null,{"name":"Next.MetadataOutlet","children":"$@4"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"PguD2ycitHEec63gmWmSO"}
4:null
