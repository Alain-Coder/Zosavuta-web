:HL["/_next/static/chunks/2so_4r2w0y9j2.css","style"]
:HL["/_next/static/chunks/24i1nr4h_dinz.css","style"]
:HL["/_next/static/chunks/0ckv5j_fni3xm.css","style"]
:HL["/_next/static/media/797e433ab948586e-s.p.0r6juujl39pe6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/83afe278b6a6bb3c-s.p.2bn3s6zvc0dyp.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/caa3a2e1cccd8315-s.p.0wgildi0cnwt9.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
0:{"tree":{"name":"","param":null,"prefetchHints":16,"slots":{"children":{"name":"bus","param":null,"prefetchHints":0,"slots":{"children":{"name":"operator","param":null,"prefetchHints":0,"slots":{"children":{"name":"buses","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}}}}}},"staleTime":300,"buildId":"PguD2ycitHEec63gmWmSO"}
