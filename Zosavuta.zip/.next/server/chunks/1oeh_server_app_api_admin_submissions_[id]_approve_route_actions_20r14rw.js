module.exports=[67056,(e,o,d)=>{}];

//# sourceMappingURL=1oeh_server_app_api_admin_submissions_%5Bid%5D_approve_route_actions_20r14rw.js.map