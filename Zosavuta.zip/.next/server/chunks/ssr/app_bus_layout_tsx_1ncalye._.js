module.exports=[7464,a=>{"use strict";a.i(70396);var b=a.i(73727);a.s(["default",0,function({children:a}){(0,b.notFound)()}])},80142,a=>{a.n(a.i(7464))}];

//# sourceMappingURL=app_bus_layout_tsx_1ncalye._.js.map